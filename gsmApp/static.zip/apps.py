from django.apps import AppConfig


class GsmAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gsmApp'
    verbose_name = 'gsmapp'
   
